---
description: Stage changes, write a conventional commit message, and commit.
---

# /commit

Create one clean commit for the current changes.

## Steps

1. Run `git status` and `git diff` to see what changed.
2. Group the changes into a single logical commit. If they are unrelated, say so and ask before splitting.
3. Write a Conventional Commits message: `type(scope): summary`.
   - types: feat, fix, refactor, docs, test, chore, perf, build, ci.
   - summary in the imperative, lower case, no trailing period, under 72 chars.
   - add a body only when the why is not obvious from the diff.
4. Stage the files and commit.
5. Print the commit hash and the one-line summary.

Do not push. Do not amend an existing commit unless asked.
