---
description: Fetch a pull request and produce a structured review.
---

# /review-pr

Review a pull request and report actionable findings.

## Steps

1. Get the PR diff (`gh pr diff <number>`) and its description.
2. Read the changed files with enough surrounding context to judge them.
3. Check, in order:
   - Correctness: logic errors, edge cases, error handling, race conditions.
   - Security: injection, secrets, authz, unsafe input.
   - Tests: are the changes covered, do the tests assert real behaviour.
   - Clarity: naming, dead code, needless complexity.
4. Report findings ranked most severe first. For each: file and line, what is wrong, and the concrete fix.
5. End with a verdict: approve, comment, or request changes.

Review only what the diff changes. Do not restate the whole file.
