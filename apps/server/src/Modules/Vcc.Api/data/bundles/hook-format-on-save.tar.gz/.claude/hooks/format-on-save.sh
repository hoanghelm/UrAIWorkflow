#!/usr/bin/env bash
# format-on-save — run the project formatter after a file is written or edited.
set -euo pipefail

file="${CLAUDE_FILE_PATH:-}"
[ -z "$file" ] && exit 0
[ -f "$file" ] || exit 0

case "$file" in
  *.ts|*.tsx|*.js|*.jsx|*.json|*.md|*.css)
    if command -v prettier >/dev/null 2>&1; then
      prettier --write "$file" >/dev/null 2>&1 || true
    elif [ -x node_modules/.bin/prettier ]; then
      node_modules/.bin/prettier --write "$file" >/dev/null 2>&1 || true
    fi
    ;;
esac

exit 0
