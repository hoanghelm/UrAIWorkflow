#!/usr/bin/env bash
# block-secrets — refuse writes that contain obvious credentials.
set -euo pipefail

content="${CLAUDE_FILE_CONTENT:-}"
[ -z "$content" ] && exit 0

if printf '%s' "$content" | grep -Eq \
  '(sk-ant-[A-Za-z0-9]{16,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|xox[baprs]-[0-9A-Za-z-]{10,})'; then
  echo "block-secrets: refusing to write a file that looks like it contains a credential." >&2
  exit 1
fi

exit 0
