#!/usr/bin/env bash
# notify-on-stop — desktop notification when a run finishes or needs input.
set -euo pipefail

title="${1:-Claude}"
message="${2:-Run finished}"

if command -v notify-send >/dev/null 2>&1; then
  notify-send "$title" "$message" || true
elif command -v osascript >/dev/null 2>&1; then
  osascript -e "display notification \"$message\" with title \"$title\"" || true
elif command -v powershell.exe >/dev/null 2>&1; then
  powershell.exe -NoProfile -Command "[console]::beep(880,200)" >/dev/null 2>&1 || true
fi

exit 0
